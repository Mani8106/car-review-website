import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import Reviews from "./pages/Reviews";
import ReviewDetail from "./pages/ReviewDetail.jsx";
import Categories from "./pages/Categories.jsx";
import Contact from "./pages/Contact";
import NotFound from "./pages/NotFound";
import SearchResults from "./pages/SearchResults";
import Cars from "./pages/Cars";
import CarDetail from "./pages/CarDetails";
import SingleCategoryPage from "./pages/SingleCategory";

function App() {
    return (
        <Router>
            <div className="App">
                <Header />

                {/* Routing */}
                <Routes>
                    <Route path="/" exact element={<Home />} />
                    <Route path="/reviews" element={<Reviews />} />
                    <Route path="/cars" element={<Cars />} />
                    <Route path="/reviews/:id" element={ReviewDetail} />
                    <Route path="/categories" element={<Categories />} />
                    <Route path="/searchresults" element={<SearchResults />} />
                    <Route path="/contact" exact element={<Contact />} />
                    <Route path="*" element={<NotFound />} />
                    <Route
                        path="/review/:reviewId"
                        element={<ReviewDetail />}
                    />
                    <Route path="/car/:carId" element={<CarDetail />} />
                    <Route
                        path="/category/:categorySlug"
                        element={<SingleCategoryPage />}
                    />
                </Routes>

                <Footer />
            </div>
        </Router>
    );
}

export default App;
