import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

import "./search.scss";

const Search = () => {
    const [query, setQuery] = useState("");
    const navigate = useNavigate();

    const handleSearch = () => {
        if (query.trim() !== "") {
            // Redirect to search results page with the search query as a parameter
            navigate(`/searchresults?search=${query}`);
            setQuery("");
        }
    };

    return (
        <div className="search">
            <input
                type="text"
                placeholder="Search by car name"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
            />
            <button onClick={handleSearch}>Search</button>
        </div>
    );
};

export default Search;
