import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

import "./categoryList.scss";

const CategoryList = () => {
    const [categories, setCategories] = useState([]);

    const categoryList = async () => {
        const res = axios.get(
            "http://localhost:1337/api/categories?populate=*"
        );
        setCategories((await res).data.data);
    };
    useEffect(() => {
        categoryList();
    }, []);

    return (
        <div className="categoryList">
            <ul>
                {categories.map((category) => (
                    <Link
                        to={`/category/${category.attributes.CategoryName}`}
                        key={category.id}
                    >
                        <li>
                            <p>{category.attributes.CategoryName}</p>
                        </li>
                    </Link>
                ))}
            </ul>
        </div>
    );
};

export default CategoryList;
