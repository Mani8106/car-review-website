import React, { useEffect, useState } from "react";
import axios from "axios";

import "./carList.scss";
import { Link } from "react-router-dom";

const CarList = () => {
    const [cars, setCars] = useState([]);

    const carList = async () => {
        const res = await axios.get(
            "http://localhost:1337/api/cars?populate=*"
        );
        setCars(res.data.data);
    };

    useEffect(() => {
        carList();
    }, []);

    return (
        <div className="carList">
            <ul>
                {cars.map((car) => (
                    <Link key={car.id} to={`/car/${car.id}`}>
                        <li>
                            <img
                                src={`http://localhost:1337${car.attributes.CarImage.data[0].attributes.url}`}
                                alt={`${car.attributes.CarMake} ${car.attributes.CarModel}`}
                            />
                            <div>
                                <h3 className="title">
                                    {car.attributes.CarMake}{" "}
                                    {car.attributes.CarModel}
                                </h3>
                                <p className="description">
                                    {car.attributes.Description}
                                </p>
                                <p>Price: ${car.attributes.Price}</p>
                            </div>
                        </li>
                    </Link>
                ))}
            </ul>
        </div>
    );
};

export default CarList;
