import React from "react";
import { Link } from "react-router-dom";

import "./footer.scss";

const Footer = () => {
    return (
        <footer className="footer">
            <div className="footerWrapper">
                <div className="footerColumns">
                    <div className="footerColumn">
                        <h3>Pages</h3>
                        <ul>
                            <li>
                                <Link to="/">Home</Link>
                            </li>
                            <li>
                                <Link to="/reviews">Reviews</Link>
                            </li>
                            <li>
                                <Link to="/categories">Categories</Link>
                            </li>
                            <li>
                                <Link to="/contact">Contact</Link>
                            </li>
                        </ul>
                    </div>

                    <div className="footerColumn">
                        <h3>Legal</h3>
                        <ul>
                            <li>
                                <Link to="/privacy-policy">Privacy Policy</Link>
                            </li>
                            <li>
                                <Link to="/terms-and-conditions">
                                    Terms and Conditions
                                </Link>
                            </li>
                        </ul>
                    </div>
                </div>

                <div className="footerCopyright">
                    <p>
                        &copy; {new Date().getFullYear()} Car Reviews. All
                        rights reserved.
                    </p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
