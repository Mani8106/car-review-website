import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

import "./reviewList.scss";

const ReviewList = () => {
    const [reviews, setReviews] = useState([]);

    const reviewList = async () => {
        const res = await axios.get(
            "http://localhost:1337/api/reviews?populate=*"
        );
        setReviews(res.data.data);
    };

    useEffect(() => {
        reviewList();
    }, []);

    return (
        <div className="reviewList">
            <ul>
                {reviews.map((review) => (
                    <Link key={review.id} to={`/review/${review.id}`}>
                        <li>
                            <img
                                src={`http://localhost:1337${review.attributes.ReviewImages.data[0].attributes.url}`}
                                alt=""
                            />
                            <div>
                                <h3 className="title">
                                    {review.attributes.Title}
                                </h3>
                                <p>Author: Car Reviews</p>
                                <p>Rating: {review.attributes.Rating}</p>
                                <p>{review.attributes.review}</p>
                            </div>
                        </li>
                    </Link>
                ))}
            </ul>
        </div>
    );
};

export default ReviewList;
