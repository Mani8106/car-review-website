import React, { useState } from "react";
import { Link } from "react-router-dom";
import Search from "./Search"; // Import your Search component

import "./header.scss"; // Your CSS file

function Header() {
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    const toggleMenu = () => {
        setIsMenuOpen(!isMenuOpen);
    };

    return (
        <header className="header">
            <nav className={isMenuOpen ? "open" : ""}>
                <div
                    className={`burger-menu ${isMenuOpen ? "open" : ""}`}
                    onClick={toggleMenu}
                >
                    <div className="bar1"></div>
                    <div className="bar2"></div>
                    <div className="bar3"></div>
                </div>
                <ul className={`mobileMenu ${isMenuOpen ? "show" : "hide"}`}>
                    <li>
                        <Link className="navLink" to="/" onClick={toggleMenu}>
                            Home
                        </Link>
                    </li>
                    <li>
                        <Link
                            className="navLink"
                            to="/cars"
                            onClick={toggleMenu}
                        >
                            Cars
                        </Link>
                    </li>
                    <li>
                        <Link
                            className="navLink"
                            to="/reviews"
                            onClick={toggleMenu}
                        >
                            Reviews
                        </Link>
                    </li>
                    <li>
                        <Link
                            className="navLink"
                            to="/categories"
                            onClick={toggleMenu}
                        >
                            Categories
                        </Link>
                    </li>
                    <li>
                        <Link
                            className="navLink"
                            to="/contact"
                            onClick={toggleMenu}
                        >
                            Contact
                        </Link>
                    </li>
                </ul>
                <ul className="menu">
                    <li>
                        <Link className="navLink" to="/">
                            Home
                        </Link>
                    </li>
                    <li>
                        <Link className="navLink" to="/cars">
                            Cars
                        </Link>
                    </li>
                    <li>
                        <Link className="navLink" to="/reviews">
                            Reviews
                        </Link>
                    </li>
                    <li>
                        <Link className="navLink" to="/categories">
                            Categories
                        </Link>
                    </li>
                    <li>
                        <Link className="navLink" to="/contact">
                            Contact
                        </Link>
                    </li>
                </ul>
                <Search />
            </nav>
        </header>
    );
}

export default Header;
