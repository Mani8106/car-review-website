import React from "react";
import Search from "../components/Search";
import CarList from "../components/CarList";
import ReviewList from "../components/ReviewList";
import CategoryList from "../components/CategoryList";

import "./home.scss";

const Home = () => {
    return (
        <div className="home">
            <header>
                <h1>FIND THE RIGHT CAR</h1>
                <Search />
            </header>
            <div className="homeWrapper">
                <section className="featuredCars">
                    <h2>Featured Cars</h2>
                    <CarList />
                </section>

                <section className="recentReviews">
                    <h2>Recent Reviews</h2>
                    <ReviewList />
                </section>

                <section className="categoriesSection">
                    <h2>Categories</h2>
                    <CategoryList />
                </section>
            </div>
        </div>
    );
};

export default Home;
