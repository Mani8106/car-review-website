import React, { useState, useEffect } from "react";
import { Link, useSearchParams } from "react-router-dom";
import axios from "axios";

import "./searchresults.scss";

const SearchResults = () => {
    const [searchParams] = useSearchParams();
    const [reviews, setReviews] = useState([]);
    const searchText = searchParams.get("search");

    useEffect(() => {
        const reviewList = async () => {
            const res = await axios.get(
                `http://localhost:1337/api/reviews?filters[Title][$contains]=${searchText}&populate=*`
            );
            console.log(res.data.data);
            setReviews(res.data.data);
        };
        reviewList();
    }, [searchText]);

    // const filter = reviews.attributes.Title === "Volvo C40 Recharge";
    return (
        <div className="searchresults">
            <h1>Search results for "{searchText}"</h1>
            <div className="reviewList">
                <ul>
                    {reviews.map((review) => (
                        <Link key={review.id} to={`/review/${review.id}`}>
                            <li key={review.id}>
                                <img
                                    src={`http://localhost:1337${review.attributes.ReviewImages.data[0].attributes.url}`}
                                    alt=""
                                />
                                <div>
                                    <h3 className="title">
                                        {review.attributes.Title}
                                    </h3>
                                    <p>Author: Car Reviews</p>
                                    <p>Rating: {review.attributes.Rating}</p>
                                    <p>{review.attributes.review}</p>
                                </div>
                            </li>
                        </Link>
                    ))}
                </ul>
            </div>
        </div>
    );
};

export default SearchResults;
