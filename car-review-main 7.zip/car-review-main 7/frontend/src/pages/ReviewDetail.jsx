import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";
import NotFound from "./NotFound";
import Markdown from "react-markdown";

import "./reviewDetail.scss";

const ReviewDetail = () => {
    const { reviewId } = useParams();
    const [review, setReview] = useState(null);

    useEffect(() => {
        // Fetch the details of the selected review using reviewId
        const fetchReview = async () => {
            try {
                const response = await axios.get(
                    `http://localhost:1337/api/reviews/${reviewId}?populate=*`
                );
                setReview(response.data.data);
            } catch (error) {
                console.error("API request for review details failed:", error);
            }
        };

        fetchReview();
    }, [reviewId]);

    if (!review) {
        // Handle the case when the review data is still loading
        return <NotFound />;
    }

    return (
        <div className="reviewDetails">
            <div className="mainSection">
                <img
                    src={`http://localhost:1337${review.attributes.ReviewImages.data[0].attributes.url}`}
                    alt={review.attributes.Title}
                />
                <div>
                    <h1>{review.attributes.Title}</h1>
                    <p>Author: Car Review</p>
                    <p>Published at: {review.attributes.Published}</p>
                    <p>Rating: {review.attributes.Rating}</p>
                    <Link
                        to={`/car/${review.attributes.AssociatedCar.data.id}`}
                    >
                        Check more specs here...
                    </Link>
                </div>
            </div>
            <Markdown>{review.attributes.Review}</Markdown>
            <p>Pros:</p>
            <Markdown>{review.attributes.Pros}</Markdown>
            <p>Cons:</p>
            <Markdown>{review.attributes.Cons}</Markdown>
        </div>
    );
};

export default ReviewDetail;
