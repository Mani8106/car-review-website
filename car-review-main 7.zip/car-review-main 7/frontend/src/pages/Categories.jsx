import React, { useEffect, useState } from "react";
import axios from "axios";

import "./categories.scss";
import { Link } from "react-router-dom";

const Categories = () => {
    const [categories, setCategories] = useState([]);

    useEffect(() => {
        // Fetch the list of categories from your API endpoint
        const fetchCategories = async () => {
            try {
                const response = await axios.get(
                    "http://localhost:1337/api/categories"
                );
                setCategories(response.data.data);
            } catch (error) {
                console.error("API request for categories failed:", error);
            }
        };

        fetchCategories();
    }, []);

    return (
        <div className="categories">
            <h1>Categories</h1>
            <ul>
                {categories.map((category) => (
                    <Link
                        to={`/category/${category.attributes.CategoryName}`}
                        key={category.id}
                    >
                        <li>
                            <p>{category.attributes.CategoryName}</p>
                        </li>
                    </Link>
                ))}
            </ul>
        </div>
    );
};

export default Categories;
