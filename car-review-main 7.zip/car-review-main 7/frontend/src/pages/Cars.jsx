import React from "react";
import CarList from "../components/CarList";

import "./cars.scss";

const Cars = () => {
    return (
        <div className="cars">
            <h1>Cars</h1>
            <CarList />
        </div>
    );
};

export default Cars;
