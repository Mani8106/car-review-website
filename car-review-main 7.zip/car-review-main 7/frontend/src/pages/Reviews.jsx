import React from "react";
import ReviewList from "../components/ReviewList";

import "./reviews.scss";

const Reviews = () => {
    return (
        <div className="reviews">
            <h1>Reviews</h1>
            <ReviewList />
        </div>
    );
};

export default Reviews;
