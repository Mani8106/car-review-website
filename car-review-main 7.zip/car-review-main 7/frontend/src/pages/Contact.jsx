import React from "react";

import "./contact.scss";

const Contact = () => {
    return (
        <div className="contact">
            <h1>Contact Us</h1>
            <p>
                If you have any questions or suggestions, feel free to reach out
                to us
            </p>

            <div className="contact-details">
                <p>Email: contact@example.com</p>
                <p>
                    LinkedIn:{" "}
                    <a href="https://www.linkedin.com/in/yourlinkedinprofile">
                        LinkedIn Profile
                    </a>
                </p>
                <p>
                    Facebook:{" "}
                    <a href="https://www.facebook.com/yourfacebookpage">
                        Facebook Page
                    </a>
                </p>
            </div>
        </div>
    );
};

export default Contact;
