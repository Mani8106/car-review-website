import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import axios from "axios";

import "./singleCategory.scss";

function SingleCategoryPage() {
    const { categorySlug } = useParams(); // Assuming you capture the category slug in the route

    const [reviews, setReviews] = useState([]);

    const reviewList = async () => {
        const res = await axios.get(
            "http://localhost:1337/api/reviews?populate=*"
        );
        setReviews(res.data.data);
    };

    useEffect(() => {
        reviewList();
    }, []);

    return (
        <div className="reviewList">
            <h1>{categorySlug} reviews</h1>
            <ul>
                {reviews.map(
                    (review) =>
                        review.attributes.AssociatedCategory.data.attributes
                            .CategoryName === categorySlug && (
                            <Link key={review.id} to={`/review/${review.id}`}>
                                <li>
                                    <img
                                        src={`http://localhost:1337${review.attributes.ReviewImages.data[0].attributes.url}`}
                                        alt=""
                                    />
                                    <div>
                                        <h3 className="title">
                                            {review.attributes.Title}
                                        </h3>
                                        <p>Author: Car Reviews</p>
                                        <p>
                                            Rating: {review.attributes.Rating}
                                        </p>
                                        <p>{review.attributes.review}</p>
                                    </div>
                                </li>
                            </Link>
                        )
                )}
            </ul>
        </div>
    );
}

export default SingleCategoryPage;
