import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";
// Import Swiper React components
import { Swiper, SwiperSlide } from "swiper/react";
// import required modules
import { EffectFade, Navigation } from "swiper/modules";
import NotFound from "./NotFound";

import "./carDetails.scss";
// Import Swiper styles
import "swiper/css";
import "swiper/css/effect-fade";
import "swiper/css/navigation";

const CarDetail = () => {
    const { carId } = useParams();
    const [car, setCar] = useState(null);

    useEffect(() => {
        // Fetch the details of the selected review using reviewId
        const fetchReview = async () => {
            try {
                const response = await axios.get(
                    `http://localhost:1337/api/cars/${carId}?populate=*`
                );
                setCar(response.data.data);
            } catch (error) {
                console.error("API request for review details failed:", error);
            }
        };

        fetchReview();
    }, [carId]);

    if (!car) {
        // Handle the case when the review data is still loading
        return <NotFound />;
    }

    const fullDate = new Date(`${car.attributes.YearOfManufacture}`);
    const year = fullDate.getFullYear();

    const carImages = car.attributes.CarImage.data;

    return (
        <div className="carDetails">
            <Swiper
                effect={"fade"}
                navigation={true}
                modules={[EffectFade, Navigation]}
                className="mySwiper"
            >
                {carImages.map((carImage) => (
                    <SwiperSlide key={carImage.id}>
                        <img
                            src={`http://localhost:1337${carImage.attributes.url}`}
                            alt=""
                        />
                    </SwiperSlide>
                ))}
            </Swiper>

            <h1>
                {car.attributes.CarMake} {car.attributes.CarModel} [{year}]
            </h1>
            <p className="description">{car.attributes.Description}</p>
            <p>Price: $ {car.attributes.Price}</p>
            <p>Mileage: {car.attributes.Mileage} Miles</p>
            <p>Engine: {car.attributes.EngineType}</p>
            <p>Fuel: {car.attributes.FuelType}</p>
            <p>Transmission: {car.attributes.TransmissionType}</p>
            <p>Safety: {car.attributes.safety}</p>
            <Link to={`/review/${car.attributes.AssociatedReview.data.id}`}>
                Read the review here...
            </Link>
        </div>
    );
};

export default CarDetail;
